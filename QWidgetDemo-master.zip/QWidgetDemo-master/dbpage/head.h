﻿#include <QtCore>
#include <QtGui>
#include <QtSql>
#if (QT_VERSION > QT_VERSION_CHECK(5,0,0))
#include <QtWidgets>
#endif

#pragma execution_character_set("utf-8")
